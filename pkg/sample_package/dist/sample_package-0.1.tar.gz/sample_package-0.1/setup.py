from setuptools import setup
setup(name="sample_package",
version="0.1",
description="This is a code with me",
long_description= "This is a very very long description",
author="Harry",
packages=['sample_package'],
install_requires=[])