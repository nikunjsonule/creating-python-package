def achafunc(number):
    print("This is a achafunc package")
    return number