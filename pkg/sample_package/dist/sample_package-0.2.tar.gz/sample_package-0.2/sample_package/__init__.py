def sutta(number):
    print("This is a sutta package")
    return number