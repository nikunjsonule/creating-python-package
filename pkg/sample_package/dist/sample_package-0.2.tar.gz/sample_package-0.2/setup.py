from setuptools import setup
setup(name="sample_package",
version="0.2",
description="This is a code for sutta",
long_description= "Sutta is basically refreshment mashal. Relax and calm you in stress. It's just like spirtual inhaling with nature.",
author="Sutta Guru",
packages=['sample_package'],   # sample_package name should be same as package name 
install_requires=[])